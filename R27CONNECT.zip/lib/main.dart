import 'package:flutter/material.dart';
import 'pages/home_page.dart';
import 'pages/players_page.dart';
import 'pages/managers_page.dart';
import 'pages/card_creator_page.dart';

void main() {
  runApp(const R27ConnectApp());
}

class R27ConnectApp extends StatelessWidget {
  const R27ConnectApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'R27Connect eFootball',
      theme: ThemeData.dark(),
      home: const MainPage(),
    );
  }
}

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = const [
    HomePage(),
    PlayersPage(),
    ManagersPage(),
    CardCreatorPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: _pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        type: BottomNavigationBarType.fixed,
        backgroundColor: const Color(0xFF1E293B),
        selectedItemColor: Colors.blueAccent,
        unselectedItemColor: Colors.grey,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.sports_soccer), label: 'Players'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Managers'),
          BottomNavigationBarItem(icon: Icon(Icons.style), label: 'Card Creator'),
        ],
      ),
    );
  }
}
