import 'package:flutter/material.dart';

class ManagersPage extends StatelessWidget {
  const ManagersPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        title: const Text('Managers & Formations'),
        backgroundColor: const Color(0xFF1E293B),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildManagerCard('L. Roman (Guardiola)', 'Possession Game', '88 Proficiency', '4-1-2-3'),
          _buildManagerCard('G. Zeitzler (Klopp)', 'Quick Counter', '87 Proficiency', '4-3-3'),
          _buildManagerCard('D. Simeone', 'Out Wide / Long Ball', '85 Proficiency', '4-4-2'),
        ],
      ),
    );
  }

  Widget _buildManagerCard(String name, String style, String prof, String formation) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(name, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.purple.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text(formation, style: const TextStyle(color: Colors.purpleAccent, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text('Playstyle: $style', style: const TextStyle(color: Colors.white70)),
          Text('Proficiency: $prof', style: const TextStyle(color: Colors.greenAccent)),
        ],
      ),
    );
  }
}
