import 'package:flutter/material.dart';

class PlayersPage extends StatelessWidget {
  const PlayersPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      appBar: AppBar(
        title: const Text('Player Training Guide'),
        backgroundColor: const Color(0xFF1E293B),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildPlayerCard('L. Messi', 'RWFL / AMF', '99 Overall', Colors.amber),
          _buildPlayerCard('K. Mbappé', 'LWF / CF', '98 Overall', Colors.blue),
          _buildPlayerCard('E. Haaland', 'CF', '97 Overall', Colors.cyan),
          _buildPlayerCard('J. Bellingham', 'CMF / AMF', '96 Overall', Colors.purple),
        ],
      ),
    );
  }

  Widget _buildPlayerCard(String name, String position, String rating, Color tagColor) {
    return Card(
      color: const Color(0xFF1E293B),
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: tagColor.withOpacity(0.2),
          child: Icon(Icons.person, color: tagColor),
        ),
        title: Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        subtitle: Text(position, style: const TextStyle(color: Colors.white70)),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: tagColor.withOpacity(0.2),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: tagColor),
          ),
          child: Text(rating, style: TextStyle(color: tagColor, fontWeight: FontWeight.bold)),
        ),
      ),
    );
  }
}
