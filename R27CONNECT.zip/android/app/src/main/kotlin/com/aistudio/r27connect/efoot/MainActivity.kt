package com.aistudio.r27connect.efoot

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
